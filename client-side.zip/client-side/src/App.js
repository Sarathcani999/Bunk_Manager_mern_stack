import React , {useState, Component} from 'react';
import './App.css';
import Subject from './components/subject/Subject';
import CreateSubject from './components/createSubject/createSubject' ;

export default function App() {

  const [subjects , setSubjects] = useState(['Phy' , 'Chem']) 
  fetch("viewAllSubjects").then(res => {return res.json()}).then(subs => setSubjects(subs))
  
  return (
    <div className='App'>
      <h1>Bunk Manager</h1>

      {subjects.map(subject => <Subject name = {subject.s_name} id = {subject.s_id} present = {subject.present} total = {subject.total}/>)}
      <div className="create">
        <CreateSubject /> 
      </div>
      
    </div>
    
  )

}

// class App extends Component {

//   state = {
//   }

//   usernameChangerHandler = (event) => {
//     this.setState({
//       paragraph_1 : event.target.value
//     })
//   }

  

//   render() {

//     fetch("viewAllSubjects").then(res => {return res.json()}).then(value => this.setState({subject : value}))



//     return (
//      <div className="App">
//         {/* <Subject name={this.state.subject} /> */}
//         {this.state}
//       </div>
//     );
//   }
// }

// export default App;