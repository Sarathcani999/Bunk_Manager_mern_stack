import React from 'react'



export default function CreateSubject () {
    return (
        <div>
            <input type='text' />
            <button>Add</button>
        </div>
    )
}