import React from 'react'
import './Subject.css'
import axios from 'axios'

const presentHandler = (subject_id) => {
    const data = {"subject_id" : "101"}
    console.log(data)
    
    // fetch('http://localhost:5000/markPresent', {
    //   method: "POST",
    //   mode : 'no-cors' ,
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json'
    //   },
    //   body:JSON.stringify(data)
    // })

    // fetch('http://localhost:5000/markPresent' , {
    //     method : 'POST' ,
    //     mode : 'no-cors' ,
    //     headers: {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json'
    //       },
    //     body: data
    // }).then((res) => {
    //     console.log(res)
    // })

    axios.post('http://localhost/markPresent' , data)
}

const subject = (props) => {
    return (
        <div className="subject">
            <span>{props.name}</span>
            <button onClick={() => presentHandler(props.id)}>+</button>
            <button>-</button>
            <p>{(props.present / props.total)*100} %</p>
        </div>
    )
}

export default subject