// Importing libraries
const express = require('express')
const mysql = require('mysql')
const path = require('path')


// creating an express object
app = express()


// Setting Up Static and handlebars views
app.set('views' , path.join( __dirname , './views'))
app.set('view engine' , 'hbs')
app.use(express.static(path.join(__dirname , './public')))

//Connecting Database
var connection = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'sampleDB'

})

// Connecting Database
connection.connect( (err) => {
    if(!err) {
        console.log("Connected to database")
    } else {
        console.log("Error found")
    }
})

// Routing
app.get('' , (req , res) => {
    res.render('index')
})


// Establishment of Port at 3000 
app.listen(3000 , () => {
    console.log("Port established at 3000")
})